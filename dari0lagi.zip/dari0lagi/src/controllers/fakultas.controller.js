import FakultasModel from '../models/fakultas.model.js';
import { apiResponse } from '../utils/response.js';

class FakultasController {
    static async store(req, res) {
        const { name } = req.body

        if(!name){
            return apiResponse({ 
                res, 
                status: 400, 
                message: 'Nama fakultas wajib diisi', 
            })
        }

        const newFakultas = await FakultasModel.create({ name })
        return apiResponse({ 
            res, 
            status: 201,
            data: newFakultas
        })
    }

    static async index(req, res) {
        const listFakultas = await FakultasModel.find()
        return apiResponse({ 
            res,
            status: 200,
            data: listFakultas,
        })
    }

    static async show(req, res){
        const fakultasId = req.params.id
        const fakultas = await FakultasModel.findById(fakultasId)

        if(!fakultas){
            return apiResponse({
                res,
                status: 404,
                message: 'Fakultas tidak ada',
                data: fakultas,
            })
        }

        return apiResponse({
            res,
            status: 200, 
            message: 'Detail fakultas',
            data: fakultas,
        })
    }

    static async update(req, res){
        const fakultasId = req.params.id
        const { name } = req.body 

        const exists = await FakultasModel.exists({ _id : fakultasId })
        if(!exists) {
            return apiResponse({
                res,
                status: 404,
                message: 'Fakultas tidak ada',
                data: null,
            })
        }
    }

    static async delete(req, res){
        const fakultasId = req.params.id

        const exists = await FakultasModel.exists({ _id: fakultasId })
        if(!exists) {
            return apiResponse({ 
                res,
                status: 404, 
                message: 'Fakultas tidak ditemukan'
            })
        }

        await FakultasModel.findOneAndDelete({ _id: fakultasId })
        return apiResponse({
            res,
            status: 200,
            message: 'Fakultas berhasil di hapus',
            data: null,
        })
    }
}

export default FakultasController;